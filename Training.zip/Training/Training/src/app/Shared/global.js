"use strict";
var Global = (function () {
    function Global() {
    }
    return Global;
}());
Global.BASE_USER_ENDPOINT = 'api/userapi/';
Global.SUCCESS_MESSAGE = 'Data Saved Sucessfully';
Global.ERROR_MESSAGE = 'There is some issue in saving records!';
Global.ERROR_MESSAGE_DATE = 'Please Enter Proper Dates';
exports.Global = Global;
//# sourceMappingURL=global.js.map