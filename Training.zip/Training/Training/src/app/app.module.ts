import { NgModule } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { HttpModule } from '@angular/http';
import { TrainingService } from './Service/training.service';
import { CreateTrainingComponent } from './Components/training.component'
import { RouterModule, Routes } from '@angular/router';
 

@NgModule({
    imports: [BrowserModule, HttpModule, RouterModule],
    declarations: [AppComponent, CreateTrainingComponent],
    providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TrainingService],
    bootstrap: [AppComponent]
})

const approutes: Routes = [{ path: 'Training', component: CreateTrainingComponent },
        { path: '', redirectTo: '/Training' ,pathMatch:'full'}
];

export class AppModule { }
