"use strict";
var training_component_1 = require("./Components/training.component");
var approutes = [{ path: 'Training', component: training_component_1.CreateTrainingComponent },
    { path: '', redirectTo: '/Training', pathMatch: 'full' }
];
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map