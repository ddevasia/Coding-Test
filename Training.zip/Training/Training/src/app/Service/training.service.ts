﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { HttpClient ,HttpErrorResponse} from '@angular/common/http';
import { Training } from '../model/training.model'
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable'
import { Global } from '../Shared/global'

@Injectable()
export class TrainingService {
    readonly rootUrl = 'http://localhost:51352';
    constructor(private _httpClient: HttpClient) { }

    save(training: Training) {
        {
            if (training.trainingId == null) {
                return this._httpClient.post(`$(this.rootUrl)/SaveTraining`, training)
                    .subscribe(data => console.log(Global.SUCCESS_MESSAGE, this.DateDifference),
                    (error => console.log(Global.ERROR_MESSAGE)
                    ));                         
            }
        }
}
    private HandleError(errorResponse: HttpErrorResponse) {
        if (errorResponse.error instanceof ErrorEvent) {
            console.error('Client Side Error', errorResponse.error.message);
        } else
        {
            console.error('Server Side Error', errorResponse);
        };
        return new ErrorObservable('There is some issue in the service');
    }

    private DateDifference(training: Training) {

        var date2 = new Date(training.endDate);
        var date1 = new Date(training.startDate);
        var timeDiff = Math.abs(date2.getTime() - date1.getTime());
        var dayDifference = Math.ceil(timeDiff / (1000 * 3600 * 24));

        return dayDifference;

    }
        
    
    
}