"use strict";
//# sourceMappingURL=training.model.js.map