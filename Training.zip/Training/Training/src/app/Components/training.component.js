"use strict";
var CreateTrainingComponent = (function () {
    function CreateTrainingComponent(_trainingService, _router) {
        this._trainingService = _trainingService;
        this._router = _router;
        this.training = {
            trainingId: null,
            trainingName: null,
            startDate: null,
            endDate: null
        };
    }
    CreateTrainingComponent.prototype.ngOnInit = function () {
    };
    CreateTrainingComponent.prototype.saveTraining = function () {
        this._trainingService.save(this.training);
        this._router.navigate(['Training']);
    };
    return CreateTrainingComponent;
}());
exports.CreateTrainingComponent = CreateTrainingComponent;
//# sourceMappingURL=training.component.js.map