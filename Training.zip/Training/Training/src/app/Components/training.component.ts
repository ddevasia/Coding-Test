﻿import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Training } from '../model/training.model'
import { TrainingService } from '../Service/training.service';
import { Router } from '@angular/router';

export class CreateTrainingComponent implements OnInit {
    training: Training = {
        trainingId: null,
        trainingName: null,
        startDate: null,
        endDate: null
    };
    constructor(private _trainingService: TrainingService, private _router:Router) { }

    ngOnInit() {

    }
    saveTraining(): void {
        this._trainingService.save(this.training);
        this._router.navigate(['Training']);
    }

}

